"""Layout rules layered on top of styles.py.

Every page loses the old masthead; the chat page additionally locks the
window so only the message list (and the sidebar) can scroll.
"""
import streamlit as st

BASE = """
.block-container { padding-top: 2.2rem !important; }

/* ── sidebar: always open, fixed, deep-petrol theme ───────────── */
[data-testid="stSidebarCollapseButton"], [data-testid="stSidebarCollapsedControl"],
[data-testid="stExpandSidebarButton"], [data-testid="stSidebarResizeHandle"] { display: none !important; }
@media (min-width: 900px) {
  [data-testid="stSidebar"] {
    transform: none !important; margin-left: 0 !important; visibility: visible !important;
    width: 280px !important; min-width: 280px !important; max-width: 280px !important;
  }
}
/* re-point the palette inside the sidebar; every rule in styles.py follows */
[data-testid="stSidebar"] {
  --ink: #f3eedf; --ink-2: #c6d8d4; --ink-3: #8fb0ab;
  --paper: #0b3d41; --surface: rgba(255,255,255,.09); --surface-2: rgba(255,255,255,.12);
  --rule: rgba(255,255,255,.12); --rule-strong: rgba(255,255,255,.22);
  --petrol: #f0e4c4; --petrol-deep: #fff8e3; --petrol-wash: rgba(255,255,255,.10);
  background: #0b3d41 !important; border-right: 0 !important;
}
[data-testid="stSidebar"] [data-testid="stSidebarContent"] { overflow-y: auto; }
[data-testid="stSidebar"] [data-testid="stSidebarUserContent"] { padding-bottom: 140px; }
[data-testid="stSidebar"] [data-testid="stVerticalBlock"] { gap: .35rem; }
[data-testid="stSidebar"] .stButton > button:hover { background: rgba(255,255,255,.08) !important; }
[data-testid="stSidebar"] .wordmark-text em { color: #e6bd6e; }
.sidebar-brand { padding: .6rem .15rem 1rem; }

/* history is the only scrolling region inside the sidebar */
.st-key-chat-history {
  max-height: calc(100dvh - 520px) !important; min-height: 120px;
  overflow-y: auto !important; border-bottom: 0 !important; margin-bottom: 0 !important;
}

/* account block pinned to the bottom edge */
.st-key-sidebar-account {
  position: fixed; left: 0; bottom: 0; width: 280px; z-index: 5; margin: 0;
  padding: .85rem 1rem .9rem; background: #0b3d41;
  border-top: 1px solid rgba(255,255,255,.12); gap: .1rem !important;
}
.st-key-sidebar-account .user-card { border-top: 0; margin: 0; padding: 0; }
[data-testid="stSidebar"] .st-key-sidebar_signout button {
  font-family: var(--sans); text-transform: none; letter-spacing: 0; font-size: .82rem;
  color: var(--ink-2); padding: .3rem .2rem;
}
@media (max-width: 899px) { .st-key-sidebar-account { width: 100%; } }
"""

CHAT = """
/* lock the window: nothing but the message list scrolls */
html, body, .stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"] {
  height: 100dvh; overflow: hidden !important;
}
[data-testid="stMain"] .block-container {
  max-width: 820px !important; padding: 0 20px !important;
}
.st-key-chat-shell {
  background: transparent !important; border: 0 !important; box-shadow: none !important;
  border-radius: 0 !important; overflow: visible !important; gap: 0 !important;
}
.st-key-chat-head {
  position: relative; height: 60px; justify-content: center;
  border-bottom: 1px solid var(--rule); gap: 0 !important;
}
.st-key-chat-head [data-testid="stPopover"] { position: absolute; right: 0; top: 10px; width: auto; }
.st-key-chat-head .chat-title { padding-right: 150px; }
.chat-title {
  font-size: 1.05rem !important; margin: 0 !important; max-width: 100%;
}
.st-key-chat-body {
  height: calc(100dvh - 60px - 132px);
  min-height: 0 !important; max-height: none !important;
  padding: 26px 4px 16px !important;
}
.st-key-scroll-anchor { position: absolute; height: 0; overflow: hidden; }

/* composer: Streamlit pins a top-level chat_input to the bottom */
[data-testid="stBottom"], [data-testid="stBottom"] > div { background: transparent !important; }
[data-testid="stBottomBlockContainer"], [data-testid="stBottom"] > div > div {
  max-width: 820px !important; margin: 0 auto; padding: 0 20px 22px !important;
}
[data-testid="stChatInput"] {
  border-radius: 22px !important; background: var(--surface) !important;
  border: 1px solid var(--rule-strong) !important;
  box-shadow: 0 10px 30px -14px rgba(31, 42, 43, .28) !important;
}
[data-testid="stChatInput"] textarea { font-size: .96rem !important; font-style: normal !important; }

/* turns: flat, Claude-style */
[data-testid="stChatMessage"] { margin-bottom: 30px !important; }
[data-testid="stChatMessage"] [data-testid="stMarkdownContainer"]::before { content: none !important; }
[data-testid="stChatMessage"]:has([aria-label="Chat message from assistant"]) {
  border-left: 0 !important; padding-left: 0 !important;
}
[data-testid="stChatMessage"]:not(:has([aria-label="Chat message from user"])) [data-testid="stMarkdownContainer"] :is(p, li) {
  font-family: var(--serif) !important; font-size: 1.05rem !important; line-height: 1.72 !important;
}
[data-testid="stChatMessage"]:has([aria-label="Chat message from user"]) [data-testid="stMarkdownContainer"] {
  background: var(--surface-2) !important; border: 0 !important;
  border-radius: 18px !important; padding: .65rem 1rem !important; max-width: 80% !important;
}

/* empty state */
.st-key-chat-body .blank-state { margin-top: 12vh; max-width: 520px; }
.blank-state h3 { font-size: 2rem !important; }
.st-key-suggestions .stButton > button {
  min-height: 0 !important; padding: .55rem 1rem !important; border-radius: 999px !important;
}
.st-key-chat-head [data-testid="stPopover"] > button { border-radius: 999px; min-height: 2.4rem; }

@media (max-width: 640px) {
  [data-testid="stMain"] .block-container { padding: 0 12px !important; }
  .st-key-chat-body { height: calc(100dvh - 60px - 120px); }
}
"""


def inject(chat_page: bool):
    st.markdown(f"<style>{BASE}{CHAT if chat_page else ''}</style>", unsafe_allow_html=True)